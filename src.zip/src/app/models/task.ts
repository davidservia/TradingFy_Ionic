export interface Task {
  id:number;
  name: string;
  time: number;
  picture: string;
}
