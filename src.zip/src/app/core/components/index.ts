export * from './person/person.component';
export * from "./person-detail/person-detail.component";
export * from "./task/task.component";
export * from "./task-detail/task-detail.component";
export * from './assignment/assignment.component';
export * from './assignment-detail/assignment-detail.component';
export * from './person-selectable/person-selectable.component';
export * from './task-selectable/task-selectable.component';