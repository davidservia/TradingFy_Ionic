export interface Assign {
  id:number;
  personId:number;
  taskId:number;
  createdAt:string;
  dateTime:string;
}
  /*
  2023-01-01T00:00:00+01:00
  ISO 8601 YYYY-MM-DDTHH:mm:ss+HH:MM
  */