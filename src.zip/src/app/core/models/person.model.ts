export interface Person {
  id: number;
  name: string;
  surname: string;
  nickname: string;
  picture: string;
}
