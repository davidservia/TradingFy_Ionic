export function isLowResolution():boolean{
  return window.innerWidth < 570;
}