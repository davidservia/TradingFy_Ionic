import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gtareas',
  templateUrl: './gtareas.page.html',
  styleUrls: ['./gtareas.page.scss'],
})
export class GtareasPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
